#!/usr/bin/env python3
# Python 3.6

# Import the Halite SDK, which will let you interact with the game.
import hlt

# This library contains constant values.
from hlt import constants

# This library contains direction metadata to better interface with the game.
from hlt.positionals import Direction
#from hlt.entity import Entity,Shipyard

# This library allows you to generate random numbers.
import random

# Logging allows you to save messages for yourself. This is required because the regular STDOUT
#   (print statements) are reserved for the engine-bot communication.
import logging

""" <<<Game Begin>>> """

# This game object contains the initial game state.
game = hlt.Game()
# At this point "game" variable is populated with initial map data.
# This is a good place to do computationally expensive start-up pre-processing.
# As soon as you call "ready" function below, the 2 second per turn timer will start.
game.ready("MyPythonBot")

# Now that your bot is initialized, save a message to yourself in the log file with some important information.
#   Here, you log here your id, which you can always fetch from the game object by using my_id.
logging.info("Successfully created bot! My Player ID is {}.".format(game.my_id))

""" <<<Game Loop>>> """
while True:
    # This loop handles each turn of the game. The game object changes every turn, and you refresh that state by
    #   running update_frame().
    game.update_frame()
    # You extract player metadata and the updated map metadata here for convenience.
    me = game.me
    game_map = game.game_map

    # A command queue holds all the commands you will run this turn. You build this list up and submit it at the
    #   end of the turn.
    command_queue = []
    too_many_ships = 0
    for ship in me.get_ships():
        # For each of your ships, move randomly if the ship is on a low halite location or the ship is full.
        #   Else, collect halite.
        if ship.is_full:
            logging.info("is this condition even happening?")
            surrounding_cardinals_full_ship = ship.position.get_surrounding_cardinals()
            cardinals = []
            counter_for_positions_with_shipyard = 0
            for cardinal_position in surrounding_cardinals_full_ship:
                logging.info(f"There is a Shipyard True or False? Ans: {game_map[cardinal_position].has_structure}")
                if game_map[cardinal_position].has_structure:
                    logging.info(f"Type of structure: {game_map[cardinal_position].structure_type}")
                    logging.info(f"The structure is at position: {cardinal_position} or if that doesn't log properly it might be {game_map[cardinal_position]}")
                    #just to see if shipyard actually shows up at the present location
                    cardinals.append(cardinal_position)
                    cardinal_position_with_shipyard = cardinal_position
                    counter_for_positions_with_shipyard += 1
                else:
                    cardinals.append(cardinal_position) #gonna just add the normal cardinal position
                    #using numbers as opposed to string to see if it'll work
            logging.info(f"List of Cardinal Positions: {cardinals}")
            logging.info(f"Counter For Positions With Shipyard: {counter_for_positions_with_shipyard}")
            if counter_for_positions_with_shipyard > 0 and len(cardinals) > 0:
                logging.info("Ship is right next to the shipyard and is about to attempt going in!!")
                for i in range(0,len(cardinals)):
                    if cardinals[i] == cardinal_position_with_shipyard:
                        if i == 0:
                                command_queue.append(ship.move(Direction.North))
                        elif i == 1:
                                command_queue.append(ship.move(Direction.South))
                        elif i == 2:
                                command_queue.append(ship.move(Direction.East))
                        elif i == 3:
                                command_queue.append(ship.move(Direction.West))
            else:
                naive_direction = game_map.naive_navigate(ship, me.shipyard.position)
                command_queue.append(ship.move(naive_direction))
                #this command alone apparently doesn't allow the ship to go into the shipyard
                logging.info(f"Ship is full and command_queue has appended the {naive_direction}")
        else:
            #if the position the ship is on has halite then the ship should stay there and collect the halite
            if game_map[ship.position].halite_amount > 0:
                command_queue.append(ship.stay_still())
            else:
                #This portion checks the surrounding cardinals and whichever one has the most halite, that's the direction the ship will go in
                surrounding_cardinals = ship.position.get_surrounding_cardinals()
                halite_amounts = []
                for cardinal_position in surrounding_cardinals:
                    if not game_map[cardinal_position].is_occupied:
                        halite_amounts.append(game_map[cardinal_position].halite_amount)
                    else:
                        #Because in the next step I am selecting based on index values from order, I have to include some element as not to mess it up
                        halite_amounts.append(0)
                        #had to append 0 here because the max function wouldn't work if I appended a string
                #order is north, south, east, west
                max_halite_amount = max(halite_amounts)
                if max_halite_amount != 0:
                    for i in range(0,len(halite_amounts)):
                        #logging.info(f"{i}") #to see how im getting an index out of bounds error
                        if max_halite_amount == halite_amounts[i]:
                            cardinal_index = i
                            if i == 0:
                                command_queue.append(ship.move(Direction.North))
                                break #added breaks in case there are multiple 'maxes' so that way multiple commands won't be added
                            elif i == 1:
                                command_queue.append(ship.move(Direction.South))
                                break
                            elif i == 2:
                                command_queue.append(ship.move(Direction.East))
                                break

                            elif i == 3:
                                command_queue.append(ship.move(Direction.West))
                                break
                    logging.info(f"max_halite_amount: {max_halite_amount}, the ship has moved to that direction and has collected the halite there")
                else:
                    logging.info(f"Because max_halite_amount: {max_halite_amount}, the ship will move to a random cardinal")
                    #have to limit the random so that ships don't go into the same block as others
                    surrounding_cardinals = ship.position.get_surrounding_cardinals()
                    possible_choices = []
                    possible_choices_no_ships = 0
                    for cardinal_position in surrounding_cardinals:
                        if not game_map[cardinal_position].is_occupied:
                            #only add choices where there is no ship
                            possible_choices.append(game_map[cardinal_position].halite_amount)
                            possible_choices_no_ships += 1
                        else:
                            #Because in the next step I am selecting based on index values from order, I have to include some element as not to mess it up
                            possible_choices.append("this index contains a ship so don't go here lol")
                            #based on the choice move accordingly
                            #order is north, south, east, west
                    if possible_choices_no_ships > 0:
                        choice = random.randrange(0,len(possible_choices))
                        while possible_choices[choice] == "this index contains a ship so don't go here lol":
                            #guaranteed to get a choice that will result in the ship moving into a spot that is not occupied
                            choice = random.randrange(0,len(possible_choices))
                        if choice == 0:
                                command_queue.append(ship.move(Direction.North))
                        elif choice == 1:
                                command_queue.append(ship.move(Direction.South))
                        elif choice == 2:
                                command_queue.append(ship.move(Direction.East))
                        elif choice == 3:
                                command_queue.append(ship.move(Direction.West))
                        logging.info(f"Length of Possible Choices: {possible_choices}, and Random Choice: {choice}")
                    else: #possible choices are 0 don't move the ship or spawn anymore ships just yet
                        logging.info(f"Length of Possible Choices: {possible_choices}, so the ship has decided to stay still")
                        ship.stay_still()
                        #don't want to move the ship or else it'll collide
                        too_many_ships += 1
                        logging.info(f"too_many_ships value: {too_many_ships}")
                        #using this variable so that I know not to spawn anymore ships

    # If the game is in the first 200 turns and you have enough halite, spawn a ship.
    # Don't spawn a ship if you currently have a ship at port, though - the ships will collide.
    ship_counter = 0
    logging.info(f"this value is right above the if statement too_many_ships value: {too_many_ships}")
    if game.turn_number <= 200 and me.halite_amount >= constants.SHIP_COST and not game_map[me.shipyard].is_occupied and too_many_ships == 0:
        logging.info("Spawning Ships")
        command_queue.append(me.shipyard.spawn())
        #ship_counter += 1
        #logging.info(f"Current Ship Counter: {ship_counter}")

    # Send your moves back to the game environment, ending this turn.
    too_many_ships = 0
    game.end_turn(command_queue)

    #what I had but I'm just going to redo this whole thing
#       if game_map[ship.position].halite_amount < constants.MAX_HALITE / 10:
#            if me.halite_amount >= constants.MOVE_COST_RATIO and not ship.is_full:
#                logging.info(f"{me.halite_amount}")
#                logging.info(f"The MOVE_COST_RATIO: {constants.MOVE_COST_RATIO}")
#                command_queue.append(
#                    ship.move(
#                        random.choice([ Direction.North, Direction.South, Direction.East, Direction.West ])))
#            elif ship.is_full:
#                naive_direction = ship.naive_navigate(game_map[shipyard.position])
#                command_queue.append(ship.move(naive_direction))
#                logging.info(f"Ship is full and command_queue has appended the {naive_direction}")
#
#        else:
#            logging.info("the else case where the ship just stays still")
#            command_queue.append(ship.stay_still())
